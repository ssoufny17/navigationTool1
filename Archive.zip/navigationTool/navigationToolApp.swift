//
//  navigationToolApp.swift
//  navigationTool
//
//  Created by Sarah Soufny on 8/16/23.
//

import SwiftUI
struct navigationToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
struct McDonaldsMapApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                MapView()
            }
        }
    }
}

